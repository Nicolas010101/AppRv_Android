#!/usr/bin/python
# -*- coding: utf-8 -*-

from flask import *
import json
import mysql.connector

# Créer l'objet Application Flask (Serveur)
app = Flask( __name__ )	

# Obtenir une connexion au SGBDR
connexionBD = mysql.connector.connect(
			host = 'localhost' ,
			user = 'root' ,
			password = 'azerty' ,
			database = 'AppGSB'
		)

# Page d'accueil
@app.route( '/' )
def accueil() :
	# Retourne un simple message (texte brut)
	return "AppRv Services web"

# Connexion d'un utilisateur
@app.route( '/seconnecter/<matricule>/<mdp>' , methods=['GET'] )
def seConnecter( matricule, mdp) :
	pass
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	'''On récupère le num du dernier rapport de visite du visiteur 
	pour le mettre dans la session et l'insérer par la suite 
	dans le RV qu'il créera'''
	curseur.execute( 'select v.VIS_NOM, v.VIS_PRENOM, MAX(rv.RAP_NUM) from VISITEUR v INNER JOIN RAPPORT_VISITE rv ON v.VIS_MATRICULE = rv.VIS_MATRICULE where v.VIS_MATRICULE = %s AND v.VIS_MDP = %s ' , (matricule, mdp) )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()

	#Parcourir tous les tuples qui résultent de l'exécution de la requête
	for unTuple in tuples :
		# Convertir le tuple en dictionnaire 
		'''Si le visiteur n'a pas encore de rapport on lui attribut 
		le num "-1" et le prochain qu'il enregistrera sera donc le "0"
		Sinon on lui donne le num de son dernier rapport qui sera 
		incrémenté dans l'appli pour enregistrer son prochain rapport'''
		if unTuple[2] == None  :
			
			unVisiteur = { 'nom': unTuple[0] , 'prenom': unTuple[1] , 'numRapport' : -1 }
	
		else :
			unVisiteur = { 'nom': unTuple[0] , 'prenom': unTuple[1] , 'numRapport' : unTuple[2] }
		
	# Convertir le visiteur en chaîne au format JSON
	reponse = json.dumps( unVisiteur )
	print "Visiteur : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' ) 

# Liste des rapports de visites
@app.route( '/rv/<mois>/<annee>' , methods=['GET'] )
def getRvs( mois, annee ) :
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	
	
	"""# table RAPPORT_VISITE
 `VIS_MATRICULE` varchar(20) NOT NULL DEFAULT '',
  `RAP_NUM` int(11) NOT NULL DEFAULT '0',
  `PRA_NUM` int(11) DEFAULT NULL,
  `RAP_BILAN` varchar(510) DEFAULT '',
  `RAP_VU` varchar(3) DEFAULT 'non',
  `RAP_DATE` date DEFAULT NULL,
  `RAP_MOTIF` varchar(510) DEFAULT NULL,
  `RAP_COEFCONFIANCE` int(11) DEFAULT 0,"""
  
	# Exécuter la requête
	curseur.execute( 'select rv.RAP_NUM, rv.RAP_DATE, rv.VIS_MATRICULE, concat(v.VIS_NOM, " " , v.VIS_PRENOM) as visiteur, rv.PRA_NUM, concat(p.PRA_NOM, " " , p.PRA_PRENOM) as praticien, m.LIBELLE_MOTIF, rv.RAP_BILAN, rv.RAP_COEFCONFIANCE, rv.RAP_VU from RAPPORT_VISITE rv INNER JOIN MOTIF m ON rv.RAP_MOTIF = m.NUM_MOTIF INNER JOIN VISITEUR v ON rv.VIS_MATRICULE = v.VIS_MATRICULE INNER JOIN PRATICIEN p ON rv.PRA_NUM = p.PRA_NUM where MONTH(rv.RAP_DATE) = %s AND YEAR(rv.RAP_DATE) = %s ' , (mois, annee) )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide de rapports de visite
	RVs = []
	#Si il n'y a pas de tuple RVs prend la valeur null
	i = 0
	for tupleExiste in tuples :
		
		i += 1 
		
	if i == 0 :
		
		unRv = {}
		RVs.append( unRv )
	
	else :
		# Parcourir tous les tuples qui résultent de l'exécution de la requête
		for unTuple in tuples :
			# Convertir le tuple en dictionnaire (tableau associatif)
			unRv = { 'num': unTuple[0] , 'date': str(unTuple[1]) , 
			'visiteurMatricule': unTuple[2] , 'visiteur' : unTuple[3] ,
			'praticienNum': unTuple[4] , 'praticien' : unTuple[5] ,
			'motif': unTuple[6] , 'bilan': unTuple[7] , 
			'coefficientDeConfiance': unTuple[8] , 'vu': unTuple[9] }
			
			
			# Ajouter le dictionnaire dans la liste des rapports de visite
			RVs.append( unRv )
	
	# Convertir la liste des rapports de visite en chaîne au format JSON
	reponse = json.dumps( RVs )
	print "rapports de visite : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' ) 



# Liste des échantillons par rapport à un rv
@app.route( '/echantillons/<num>' , methods=['GET'] )
def getEchantillons( num ) :
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	
	
	"""#table MEDICAMENT
  `MED_DEPOTLEGAL` varchar(20) NOT NULL DEFAULT '',
  `MED_NOMCOMMERCIAL` varchar(50) DEFAULT NULL,
  `FAM_CODE` varchar(6) DEFAULT NULL,
  `MED_COMPOSITION` varchar(510) DEFAULT NULL,
  `MED_EFFETS` varchar(510) DEFAULT NULL,
  `MED_CONTREINDIC` varchar(510) DEFAULT NULL,
  `MED_PRIXECHANTILLON` float DEFAULT NULL,
  
  table `FAMILLE` (
  `FAM_CODE` varchar(6) NOT NULL DEFAULT '',
  `FAM_LIBELLE` varchar(160) DEFAULT NULL,
  
  TABLE `OFFRIR` (
  `VIS_MATRICULE` varchar(20) NOT NULL DEFAULT '',
  `RAP_NUM` int(11) NOT NULL DEFAULT '0',
  `MED_DEPOTLEGAL` varchar(20) NOT NULL DEFAULT '',"""
  
	# Exécuter la requête
	curseur.execute( 'select m.MED_DEPOTLEGAL, m.MED_NOMCOMMERCIAL, f.FAM_LIBELLE, m.MED_COMPOSITION, m.MED_EFFETS, m.MED_CONTREINDIC, m.MED_PRIXECHANTILLON, o.QUANTITE from MEDICAMENT m INNER JOIN FAMILLE f ON m.FAM_CODE = f.FAM_CODE INNER JOIN OFFRIR o ON m.MED_DEPOTLEGAL = o.MED_DEPOTLEGAL where o.RAP_NUM = ' + num )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide d'échantillons
	echantillons = []
	#Si il n'y a pas de tuple echantillons prend la valeur null
	i = 0
	for tupleExiste in tuples :
		
		i += 1 
		
	if i == 0 :
		
		unEchantillon = {}
		echantillons.append( unEchantillon )
	
	else :
		# Parcourir tous les tuples qui résultent de l'exécution de la requête
		for unTuple in tuples :
			# Convertir le tuple en dictionnaire (tableau associatif)
			unEchantillon = { 'depotLegal': unTuple[0] , 'nomCommercial': unTuple[1] , 
			'famille': unTuple[2] , 'composition' : unTuple[3] ,
			'effets': unTuple[4] , 'contreIndications' : unTuple[5] ,
			'prixEchantillon': unTuple[6] , 'quantite': unTuple[7] }
			
			
			# Ajouter le dictionnaire dans la liste des echantillons
			echantillons.append( unEchantillon )
	
	# Convertir la liste des echantillons en chaîne au format JSON
	reponse = json.dumps( echantillons )
	print "echantillons : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' ) 
	
	
	
# Liste des médicaments
@app.route( '/medicaments' , methods=['GET'] )
def getMedicaments() :
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	
  
	# Exécuter la requête
	curseur.execute( 'select m.MED_DEPOTLEGAL, m.MED_NOMCOMMERCIAL, f.FAM_LIBELLE, m.MED_COMPOSITION, m.MED_EFFETS, m.MED_CONTREINDIC, m.MED_PRIXECHANTILLON from MEDICAMENT m INNER JOIN FAMILLE f ON m.FAM_CODE = f.FAM_CODE' )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide d'échantillons
	echantillons = []
	#Si il n'y a pas de tuple echantillons prend la valeur null
	i = 0
	for tupleExiste in tuples :
		
		i += 1 
		
	if i == 0 :
		
		unEchantillon = {}
		echantillons.append( unEchantillon )
	
	else :
		# Parcourir tous les tuples qui résultent de l'exécution de la requête
		for unTuple in tuples :
			# Convertir le tuple en dictionnaire (tableau associatif)
			unEchantillon = { 'depotLegal': unTuple[0] , 'nomCommercial': unTuple[1] , 
			'famille': unTuple[2] , 'composition' : unTuple[3] ,
			'effets': unTuple[4] , 'contreIndications' : unTuple[5] ,
			'prixEchantillon': unTuple[6] }
			
			
			# Ajouter le dictionnaire dans la liste des echantillons
			echantillons.append( unEchantillon )
	
	# Convertir la liste des echantillons en chaîne au format JSON
	reponse = json.dumps( echantillons )
	print "echantillons : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' ) 
	
	
	
# Liste des praticiens
@app.route( '/praticiens' , methods=['GET'] )
def getPraticiens() :
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	
	
	"""#table `PRATICIEN` (
  `PRA_NUM` int(11) NOT NULL DEFAULT '0',
  `PRA_NOM` varchar(50) DEFAULT NULL,
  `PRA_PRENOM` varchar(60) DEFAULT NULL,
  `PRA_ADRESSE` varchar(100) DEFAULT NULL,
  `PRA_CP` varchar(10) DEFAULT NULL,
  `PRA_VILLE` varchar(50) DEFAULT NULL,
  `PRA_COEFNOTORIETE` float DEFAULT NULL,
  `TYP_CODE` varchar(6) DEFAULT NULL,"""
  
	# Exécuter la requête
	curseur.execute( 'select PRA_NUM, PRA_NOM, PRA_PRENOM, PRA_COEFNOTORIETE from PRATICIEN' )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide de praticiens
	praticiens = []
	#Si il n'y a pas de tuple praticiens prend la valeur null
	i = 0
	for tupleExiste in tuples :
		
		i += 1 
		
	if i == 0 :
		
		unPraticien = {}
		praticiens.append( unPraticien )
	
	else :
		# Parcourir tous les tuples qui résultent de l'exécution de la requête
		for unTuple in tuples :
			# Convertir le tuple en dictionnaire (tableau associatif)
			unPraticien = { 'num': unTuple[0] , 'nom': unTuple[1] , 
			'prenom': unTuple[2] , 'coefficientNotoriete' : unTuple[3] }
			
			
			# Ajouter le dictionnaire dans la liste des praticiens
			praticiens.append( unPraticien )
	
	# Convertir la liste des praticiens en chaîne au format JSON
	reponse = json.dumps( praticiens )
	print "praticiens : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' ) 	
	
# Liste des motifs
@app.route( '/motifs' , methods=['GET'] )
def getMotifs() :
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	
	
	"""#table `MOTIF` (
  `NUM_MOTIF` int(11) NOT NULL AUTO_INCREMENT,
  `LIBELLE_MOTIF` varchar(10) NOT NULL DEFAULT '',
  `DESC_MOTIF` varchar(100) NOT NULL DEFAULT '',"""
  
	# Exécuter la requête
	curseur.execute( 'select NUM_MOTIF, LIBELLE_MOTIF from MOTIF' )
	# Lire tous les tuples qui résultent de l'exécution de la requête
	tuples = curseur.fetchall()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide de motifs
	motifs = []
	#Si il n'y a pas de tuple motifs prend la valeur null
	i = 0
	for tupleExiste in tuples :
		
		i += 1 
		
	if i == 0 :
		
		unMotif = {}
		motifs.append( unMotif )
	
	else :
		# Parcourir tous les tuples qui résultent de l'exécution de la requête
		for unTuple in tuples :
			# Convertir le tuple en dictionnaire (tableau associatif)
			unMotif = { 'code': unTuple[0] , 'libelle': unTuple[1] }
			
			
			# Ajouter le dictionnaire dans la liste des motifs
			motifs.append( unMotif )
	
	# Convertir la liste des motifs en chaîne au format JSON
	reponse = json.dumps( motifs )
	print "motifs : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' ) 	
	
	
#Créer un rapport de visite
@app.route( '/addrv' , methods=['POST'] )
def addRv() :
	
	#Essai
	try: 
		#print "CREATE"
		# Lire et mémoriser le corps de la requête (rapport visite sous la forme d'une chaîne JSON)
		
		print '--------------------1----------------------'
		print "> " + request.form['rv']
		#unRvJSON = request.data
		print '--------------------2----------------------'
		unRvJSON = request.form['rv']
		print unRvJSON
		print '--------------------3---------------------'
		
		print '---------------------4---------------------'
		print "recept : " + unRvJSON
		# Convertir la chaîne JSON en dictionnaire
		#print u"REÇU " + unRvJSON.decode('utf-8',errors = 'ignore')
		unRv = json.loads( unRvJSON )
		print "donne " + str(unRv)
		
		
		print '---------------------5---------------------'
		# Obtenir un curseur :connexion a la bdd
		curseur = connexionBD.cursor()
		
		
		
		"""# table RAPPORT_VISITE
	 `VIS_MATRICULE` varchar(20) NOT NULL DEFAULT '',
	  `RAP_NUM` int(11) NOT NULL DEFAULT '0',
	  `PRA_NUM` int(11) DEFAULT NULL,
	  `RAP_BILAN` varchar(510) DEFAULT '',
	  `RAP_VU` varchar(3) DEFAULT 'non',
	  `RAP_DATE` date DEFAULT NULL,
	  `RAP_MOTIF` varchar(510) DEFAULT NULL,
	  `RAP_COEFCONFIANCE` int(11) DEFAULT 0,"""
		# Exécuter la requête
		curseur.execute( 'insert into RAPPORT_VISITE(VIS_MATRICULE, RAP_NUM, PRA_NUM,RAP_BILAN,RAP_DATE,RAP_MOTIF,RAP_COEFCONFIANCE) values(%s,%s,%s,%s,%s,%s,%s)' , ( unRv['visiteur'] , unRv['num'] , unRv['praticien'] , unRv['bilan'] , unRv['dateString'] , unRv['motif'] , unRv['coefficientDeConfiance'] ) )
		# Obtenir le dernier identifiant attribué
		idNouveauRv = curseur.lastrowid
		# Obtenir le nombre de tuples insérés (normallement, un seul)
		nbTuplesTraites = curseur.rowcount
		
		#COMMIT ET FERMETURE CURSEUR A LA FIN DES DIFFERENTS INSERTS
		
		# S'assurer que la BD est mise à jour
		#connexionBD.commit()
		# Fermer le curseur
		#curseur.close()
		
		
		
		
		
		
		print '---------------------requete 2---------------------'
		#recup des echantillons
		lesEchantillonsJSON = request.form['echantillons']
		print lesEchantillonsJSON
		
		#SI IL Y A DES ECHANTILLONS
		if lesEchantillonsJSON != "[]":
			print json.loads( lesEchantillonsJSON )[0]
			print "premier echant : " + json.loads( lesEchantillonsJSON )[0]["depotLegalMedoc"]

			print '---------------------1---------------------'
			
			i = 0
			while i < len( json.loads( lesEchantillonsJSON ) ) :
				
				# Convertir la chaîne JSON en dictionnaire
				print json.loads( lesEchantillonsJSON )[i]
				echant = json.loads( lesEchantillonsJSON )[i]
				
				print '---------------------2---------------------'
				print echant	
				
				# Exécuter la requête
				curseur.execute( 'INSERT INTO OFFRIR (VIS_MATRICULE, RAP_NUM, MED_DEPOTLEGAL, QUANTITE) VALUES(%s,%s,%s,%s)' , ( echant['visMatricule'] , echant['numRapport'] , echant['depotLegalMedoc'] , echant['quantite'] ) )
				i = i + 1
				
			# Obtenir le dernier identifiant attribué
			idLastEchant = curseur.lastrowid
			# Obtenir le nombre de tuples insérés (normallement, un seul)
			nbTuplesTraites = curseur.rowcount
			print '---------------------3---------------------'
		else :
			print 'pas d\'echantillons pour se rapport'
		
		# S'assurer que la BD est mise à jour
		connexionBD.commit()
		# Fermer le curseur
		curseur.close()
		
		
		# Créer un objet réponse
		reponse = make_response( '' )
		# Si les insertions se sont déroulée avec succès
		if nbTuplesTraites >= 1 :
			reponse.mimetype = 'text/plain'
			reponse.status_code = 201
			reponse.location = '/addRv/' + str( idNouveauRv )
			
		# Dans le cas contraire
		else :
			pass
			# Votre code ici
			reponse.mimetype = 'text/plain'
			reponse.status_code = 409
			reponse.location = '/addRv/' + str( -1 )
			
		return reponse
	
	##Si ca ne fonctionne pas
	except: 
		print("Erreur d'insertion")
		#curseur.rollback()
		connexionBD.rollback()
	
	
"""
	
# Créer un livreur
@app.route( '/livreurs' , methods=['POST'] )
def addLivreur() :
	#print "CREATE"
	# Lire et mémoriser le corps de la requête (livreur sous la forme d'une chaîne JSON)
	unLivreurJSON = request.data
	#print "recept : " + unLivreurJSON
	# Convertir la chaîne JSON en dictionnaire
	print u"REÇU " + unLivreurJSON.decode('utf-8',errors = 'ignore')
	unLivreur = json.loads( unLivreurJSON )
	print "donne " + str(unLivreur)
	print '-------------------------------------------'
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'insert into Livreur(nom,prenom) values(%s,%s)' , ( unLivreur['nom'] , unLivreur['prenom'] ) )
	# Obtenir le dernier identifiant attribué
	idNouveauLivreur = curseur.lastrowid
	# Obtenir le nombre de tuples insérés (normallement, un seul)
	nbTuplesTraites = curseur.rowcount
	# S'assurer que la BD est mise à jour
	connexionBD.commit()
	# Fermer le curseur
	curseur.close()
	
	# Créer un objet réponse
	reponse = make_response( '' )
	# Si l'insertion du livreur s'est déroulée avec succès
	if nbTuplesTraites == 1 :
		reponse.mimetype = 'text/plain'
		reponse.status_code = 201
		reponse.location = '/livreurs/' + str( idNouveauLivreur )
		
	# Dans le cas contraire
	else :
		pass
		# Votre code ici
		reponse.mimetype = 'text/plain'
		reponse.status_code = 409
		reponse.location = '/livreurs/' + str( -1 )
		
	return reponse
	
	
	
# Supprimer un livreur
@app.route( '/livreurs/<idLivreur>' , methods=['DELETE'] )
def deleteLivreur( idLivreur ) :
	pass
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'delete from Livreur where id = %s ' , (idLivreur,) )
	# Obtenir le nombre de tuples insérés (normallement, un seul)
	nbTuplesTraites = curseur.rowcount
	# S'assurer que la BD est mise à jour
	connexionBD.commit()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide de livreurs

	#Si il n'y a pas de ligne 0 ligne supprimée sinon 1
		
	if nbTuplesTraites == 1 :
		
		reponse = 'True'
	
	else :
		
		reponse = 'False'
			
		
	print "supprimé : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' ) 
	
	
	
	
# Modifier un livreur
@app.route( '/livreurs' , methods=['PUT'] )
def updateLivreur() :
	# Lire et mémoriser le corps de la requête (livreur sous la forme d'une chaîne JSON)
	unLivreurJSON = request.data
	#print "recept : " + unLivreurJSON
	# Convertir la chaîne JSON en dictionnaire
	#print u"REÇU " + unLivreurJSON.decode('utf-8',errors = 'ignore')
	unLivreur = json.loads( unLivreurJSON )
	# Obtenir un curseur
	curseur = connexionBD.cursor()
	# Exécuter la requête
	curseur.execute( 'UPDATE Livreur SET nom = %s, prenom = %s WHERE id = %s ' , ( unLivreur['nom'] , unLivreur['prenom'] , unLivreur['id'] ) )
	# Obtenir le nombre de tuples insérés (normallement, un seul)
	nbTuplesTraites = curseur.rowcount
	# S'assurer que la BD est mise à jour
	connexionBD.commit()
	# Fermer le curseur
	curseur.close()
	# Créer une liste vide de livreurs

	#Si il n'y a pas de ligne 0 ligne supprimée sinon 1
		
	if nbTuplesTraites == 1 :
		
		reponse = 'True'
	
	else :
		
		reponse = 'False'
			
		
	print "Modifié : " + reponse
	# Renvoyer la réponse au client HTTP
	return Response( reponse , status=200 , mimetype='application/json' ) 
	
	
	"""
	
	
# Programme principal
if __name__ == "__main__" :
	# Démarrer le serveur
	app.run( debug = True , host = '0.0.0.0' , port = 5000 )
